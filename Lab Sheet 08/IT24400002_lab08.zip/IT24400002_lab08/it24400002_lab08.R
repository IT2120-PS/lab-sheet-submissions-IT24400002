weight_kg <- c(2.46, 2.45, 2.47, 2.71, 2.46, 2.05, 2.6, 2.42, 2.43, 2.53,
               2.57, 2.85, 2.7, 2.53, 2.28, 2.2, 2.57, 2.89, 2.51, 2.47,
               2.66, 2.06, 2.41, 2.65, 2.76, 2.43, 2.61, 2.57, 2.73, 2.17,
               2.67, 2.05, 1.71, 2.32, 2.23, 2.76, 2.7, 2.13, 2.75, 2.2)

population_mean_weight <- mean(weight_kg)
population_sd_weight <- sd(weight_kg)

cat("Population Mean of Weight (kg): ", population_mean_weight, "\n")
cat("Population Standard Deviation of Weight (kg): ", population_sd_weight, "\n")

set.seed(123)  
sample_means_weight <- numeric(25)
sample_sds_weight <- numeric(25)

for (i in 1:25) {
  sample_weight <- sample(weight_kg, size = 6, replace = TRUE)
  sample_means_weight[i] <- mean(sample_weight)
  sample_sds_weight[i] <- sd(sample_weight)
}

cat("Sample Means of Weight (kg): ", sample_means_weight, "\n")
cat("Sample Standard Deviations of Weight (kg): ", sample_sds_weight, "\n")

mean_of_sample_means_weight <- mean(sample_means_weight)
sd_of_sample_means_weight <- sd(sample_means_weight)

cat("Mean of Sample Means of Weight (kg): ", mean_of_sample_means_weight, "\n")
cat("Standard Deviation of Sample Means of Weight (kg): ", sd_of_sample_means_weight, "\n")

cat("\nRelationship with True Mean and Standard Deviation:\n")
cat("True Mean of Weight (kg) is: ", population_mean_weight, "\n")
cat("True SD of Weight (kg) is: ", population_sd_weight, "\n")
cat("The mean of the sample means should be close to the population mean.\n")
cat("The standard deviation of the sample means is typically smaller than the population standard deviation.\n")
cat("This is because the standard deviation of sample means (standard error) decreases with larger sample sizes.\n")

