setwd('C:/Users/User/Desktop/Lab06')

pbinom(46, 50, 0.85, lower.tail = FALSE)
1-pbinom(46, 50, 0.85)

dpois(15, 12)
